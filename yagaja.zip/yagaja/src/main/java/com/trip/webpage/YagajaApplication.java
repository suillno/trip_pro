package com.trip.webpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YagajaApplication {

	public static void main(String[] args) {
		SpringApplication.run(YagajaApplication.class, args);
	}

}
